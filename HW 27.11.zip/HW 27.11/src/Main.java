import java.util.Objects;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // 1 уровень сложности: Задание 1
        //Напиши программу, которая моделирует ситуацию.
        //Ты попросил(а) друзей скинуться на подарок на твой День Рождения.
        // Каждый друг случайным образом может подарить тебе одну купюру
        // номиналом 50, 100, 200 или 500 долларов.
        //Твоя цель - новенький игровой компьютер, который стоит 10 000 долларов.
        //Как только друзья подарят тебе нужную сумму (или даже чуть больше),
        // останавливай сбор подарков и веди всех выпить за твоё здоровье
        // в лучший бар города!
        //Задание 2
        //Используйте for для вычисления суммы.
        //Используйте do-while для организации повторения программы.
        //Необходимо суммировать все нечётные целые числа в диапазоне,
        // введённом пользователем. Программу повторять, пока пользователь
        // не введёт «quit».
        //
        //
        //Задание 3
        //Используйте foreach.
        //Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
        // Программа должна вывести все дни недели, кроме данного.
      //giftBirthday();
        //getSum();
        getDay();
    }

private static void getDay(){
        Scanner scr = new Scanner(System.in);
    System.out.println( "enter day of week: ");
    String user = scr.next();
    for (Days day:Days.values()) {
        if (!user.toUpperCase().equals(day.toString())){
        System.out.println(day);
    }}
}
    private static void getSum () {
       String answer= "";
       do {
        Scanner scr = new Scanner(System.in);
        System.out.println("enter first number: ");
        int start = scr.nextInt();
        System.out.println("enter second number: ");
        int stop = scr.nextInt();
        int sum = 0;
        for (int i = start; i <= stop; i++) {
            if (i % 2 != 0) {
                sum += i;
            }
        }
        System.out.println(sum);
            System.out.println("play again or quit? ");
           answer = scr.next();
    } while (!Objects.equals(answer, "quit"));}

    private static void giftBirthday(){
        int goal = 0;
        Random rnd =new Random();
        while (goal <= 10000){
            int frand = rnd.nextInt(4);
            int gift = switch (frand) {
                case 0 -> 50;
                case 1 -> 100;
                case 2 -> 200;
                default -> 500;
            };
            goal += gift;
        }
        System.out.println(goal);
    }
}