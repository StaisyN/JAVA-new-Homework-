public enum Days {
    MONTAG,
    DIENSTAG,
    MITWOCH,
    DONNERSTAG,
    FREITAG,
    SAMSTAG,
    SONNTAG
}
