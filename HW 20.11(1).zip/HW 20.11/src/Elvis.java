import java.util.Scanner;

public class Elvis {
    public static void main(String[] args) {
        ////№3 Элвис Пресли жил с 1935 по 1977 год. Используя тернарные операторы,
        // напишите программу,
        // в которой пользователь вводит год. Если указанный год меньше 1935, то вывести
        // «Элвис ещё не родился». Если указанный пользователем год с 1935 по 1977 включительно,
        //  «Элвис жив!». Если введённый пользователем год больше 1977,
        // то вывести «Элвис навсегда в наших сердцах!»

        Scanner scr = new Scanner(System.in);
        System.out.println( "enter Year: ");
        int year = scr.nextInt();
        System.out.println(year < 1935 ? "Элвис ещё не родился" : "" );
        System.out.println(year >=1935 && year <= 1977 ? "Элвис жив!" : "");
        System.out.println(year > 1977 ? "Элвис навсегда в наших сердцах!" : "" );
    }
}
