import java.util.Random;
import java.util.Scanner;

public class Multi {
    //Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
    // Программа генерирует два целых однозначных числа. Программа задаёт вопрос: результат
    // умножения первого числа на второе?  Пользователь должен ввести ответ и увидеть на экране
    // правильно он ответил или нет.
    // Если пользователь ответил неправильно, то программа должна показать правильный ответ.
    public static void main(String[] args) {
    Scanner scr = new Scanner(System.in);
    Random rnd = new Random();
    int fnumber = rnd.nextInt(10);
    int snumber = rnd.nextInt(10);
    int result = fnumber*snumber;
        System.out.println(fnumber + "*" + snumber);
        int answ = scr.nextInt();
        if (answ != result){
            System.out.println(result);
        }

    }
}
