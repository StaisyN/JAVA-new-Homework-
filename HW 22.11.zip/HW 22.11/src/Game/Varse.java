package Game;

public enum Varse {
    STONE,
    PAPER,
    SCISSORS

}
