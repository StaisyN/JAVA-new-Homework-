import Game.Varse;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь вводит, сколько лет он состоит в браке.
        // Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей
        // (бумажная, ситцевая, чугунная, серебряная и.д.).
        // Не обязательно указывать все годовщины, достаточно 10-15.
        // Узнать про годовщины можно, например, здесь https://instalook.ru/blog/nazvaniya-vseh-godovschin-svadeb-do-100-let
        weddingYaers();
        //Задание 2.
        //Напишите консольную игру «Камень, ножницы, бумага».
        // Пользователь вводит свой выбор (в виде строки или числа).
        // Программа случайным образом делает свой выбор и
        // выводит на экран. Далее программа показывает, кто победитель – пользователь или программа.
game();
    }
    private static void game (){
        Scanner scr = new Scanner(System.in);
        System.out.println("enter your choice: ");
        String userChoice = scr.nextLine();
        Varse user = Varse.valueOf(userChoice.toUpperCase());
        System.out.println(user);
        Random rnd = new Random();
        int compChoice = rnd.nextInt (3);
        Varse comp = switch (compChoice){
            case 0 -> Varse.STONE;
            case 1 -> Varse.PAPER;
            default -> Varse.SCISSORS;
        };
        System.out.println(comp);
        if (comp == user){
            System.out.println("draw ");
        } else if (user == Varse.PAPER && comp == Varse.STONE || user == Varse.SCISSORS && comp == Varse.PAPER
        || user == Varse.STONE && comp == Varse.SCISSORS){
            System.out.println("won user ");
        }
        else System.out.println("won comp ");


    }

    public static void weddingYaers() {
        Scanner scr = new Scanner(System.in);
        System.out.print("enter Years: ");
        int user = scr.nextInt();
        Weddings year = switch (user + 1) {
            case 1 -> Weddings.SITZEVAYA;
            case 2 -> Weddings.BUMAZNAYA;
            case 3 -> Weddings.KOZHANAYA;
            case 4 -> Weddings.LNANAYA;
            case 5 -> Weddings.DEREVANAYA;
            case 6 -> Weddings.CHUGUNNAYA;
            case 8 -> Weddings.MEDNAYA;
            case 9 -> Weddings.ZHESTANAYA;
            case 10 -> Weddings.FAYANSOVAYA;
            case 11 -> Weddings.OLOVANNAYA;
            case 12 -> Weddings.STALNAYA;
            case 13 -> Weddings.NIKILIEVAYA;
            case 14 -> Weddings.AGATOVAYA;
            case 15 -> Weddings.CHRUSTALNAYA;
            default -> throw new IllegalStateException(" we are not know this weeding! So sorry." + user);
        };
        System.out.println("your next weeding is> " + year);
    }
}