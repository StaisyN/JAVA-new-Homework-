import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
        // которую дал покупатель.Выведите сумму сдачи в виде “X рублей и Y копеек”

        System.out.println("Price ");
        Scanner scr = new Scanner(System.in);
        double price = scr.nextDouble();
        System.out.println("Enter amount ");
       double many = scr.nextDouble();

       double change = many - price;
        System.out.println( change);

        int rub = (int)change;
        System.out.println(rub);
        int kopeek = (int)((change-rub)*100);
        System.out.println(kopeek);
    }
}
