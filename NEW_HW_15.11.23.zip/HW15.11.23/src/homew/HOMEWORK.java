package homew;
// 2 Пользователь вводит, за какое количество минут он пробежал марафон (42 км).
// Программа должна вывести на сколько часов и минут пользователь медленнее,
// чем чемпион мира, пробежавший марафон за 2 часа 1 минуту.
// Выведите результат в виде: “Вы медленнее на X часов и Y минут”.

import java.util.Scanner;
//4 Пользователь вводит целое число. Напишите программу,
// которая делит это число на 2 и выводит результат.
// Остаток деления можно отбросить. Операторы деления / и остатка
// от деления % применять нельзя.
public class HOMEWORK {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.print("какое количество минут: ");
        int min = scr.nextInt();
        int champ = 121;
        if (min > champ){
            int dif = min-champ;
            int hour = dif/60;
            int minute = dif%60;
            System.out.println("Вы медленнее чемпиона на "+ hour +" часов "+minute + " минут");

        } else {
            int dif = champ-min;
            int hour = dif/60;
            int minute = dif%60;
            System.out.println("Вы быстрее чемпиона на "+ hour +" часов "+minute + " минут");
        }
//3 Когда закончится учебный год (isYearFinished)
// и если будет солнечная погода (isGoodWeather), то ребята пойдут в поход.
// Если тур кружок закупит дождевики (hasBoughtRaincoats) к концу учебного года,
// то ребята пойдут в поход даже в плохую погоду. В поход ребят должен кто-то повести.
// Поведёт тренер Джим, если он освободится от сдачи тренерского экзамена (isJimFree),
// или тренер Кейт, если она вернётся из путешествия (hasKateComeBack).
// Вести детей может только один тренер. Если Джим и Кейт смогут вести детей вместе,
// то они обязательно поссорятся из-за этого и никто никуда не пойдёт.
//Напишите логическое выражение для вычисления того, состоится ли поход.
// Подберите условия, при которых поход состоится.


        boolean isYearFinished = true;
        boolean isGoodWeather = true;
        boolean hasBoughtRaincoats = true;
        boolean isJimFree = false;
        boolean hasKateComeBack = true;
        boolean trip = isYearFinished && (isGoodWeather || hasBoughtRaincoats) && (isJimFree ^ hasKateComeBack);
        System.out.println(trip);

//4 Пользователь вводит целое число. Напишите программу,
// которая делит это число на 2 и выводит результат.
// Остаток деления можно отбросить. Операторы деления / и остатка
// от деления % применять нельзя.

        Scanner sc = new Scanner(System.in);
        System.out.println("ввeдитe целое число: ");
        int user = sc.nextInt();
        int result = 1;
        System.out.println( user >> result);


    }
}
